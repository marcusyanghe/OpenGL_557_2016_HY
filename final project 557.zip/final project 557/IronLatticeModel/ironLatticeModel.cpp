//
// IronLatticeModel.cpp
//for final project 557. 
//


// stl include
#include <iostream>
#include <string>

// GLEW include
#include <GL/glew.h>

// GLM include files
#define GLM_FORCE_INLINE
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>


// glfw includes
#include <GLFW/glfw3.h>


// include local files
#include "controls.h"
#include "HCI557Common.h"
#include "CoordSystem.h"
#include "Sphere3D.h"
#include "GLAppearance.h"




using namespace std;


// The handle to the window object
GLFWwindow*         window;

// Define some of the global variables we're using for this sample
GLuint program;

/* A trackball to move and rotate the camera view */
extern Trackball trackball;



int main(int argc, const char * argv[])
{
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //// Init glfw, create a window, and init glew
    
    // Init the GLFW Window
    window = initWindow();
    
    
    // Init the glew api
    initGlew();
    
    

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //// Create some models
    
    // coordinate system
    CoordSystem* cs = new CoordSystem(100.0);

    
    // create an apperance object.
    GLAppearance* apperance = new GLAppearance("../../data/shaders/multi_vertex_lights.vs", "../../data/shaders/multi_vertex_lights.fs");
    
    
    // The spotlight object
    GLSpotLightSource  light_source1;
    light_source1._lightPos = glm::vec4(20.0,20.0,0.0, 1.0);
    light_source1._ambient_intensity = 0.3;
    light_source1._specular_intensity = 8.0;
    light_source1._diffuse_intensity = 3.0;
    light_source1._attenuation_coeff = 0.02;
    light_source1._cone_angle = 12.0; // in degree
    light_source1._cone_direction = glm::vec3(-1.0, -1.0, 0.0); // this must be aligned with the object and light position.
    
    
    GLDirectLightSource  light_source2;
    light_source2._lightPos = glm::vec4(20.0,0.0,0.0, 0.0);
    light_source2._ambient_intensity = 0.1;
    light_source2._specular_intensity = 5.5;
    light_source2._diffuse_intensity = 1.0;
    light_source2._attenuation_coeff = 0.02;
   // light_source2._cone_angle = 12.0; // in degree
   // light_source2._cone_direction = glm::vec3(-1.0, 0.0, 0.0); // this must be aligned with the object and light position.
    
    
    // add the spot light to this apperance object
    apperance->addLightSource(light_source1);
    apperance->addLightSource(light_source2);
    
    // Create a material object
    GLMaterial material;
    material._diffuse_material = glm::vec3(0.0, 0.0, 1.0);
    material._ambient_material = glm::vec3(0.0, 0.0, 1.0);
    material._specular_material = glm::vec3(1.0, 1.0, 1.0);
    material._shininess = 12.0;
    
    // Add the material to the apperance object
    apperance->setMaterial(material);
    apperance->finalize();
    
    // create the iron lattice skeleton composed by 27 spheres
	//layer1
    GLSphere3D* sphere1 = new GLSphere3D(0.0, 0.0, 0.0, 4.0, 90, 50);
    sphere1->setApperance(*apperance);
    sphere1->init();
    
	GLSphere3D* sphere2 = new GLSphere3D(8.0, 0.0, 0.0, 4.0, 90, 50);
	sphere2->setApperance(*apperance);
	sphere2->init();
    
	GLSphere3D* sphere3 = new GLSphere3D(16.0, 0.0, 0.0, 4.0, 90, 50);
	sphere3->setApperance(*apperance);
	sphere3->init();

	GLSphere3D* sphere4 = new GLSphere3D(0.0, 8.0, 0.0, 4.0, 90, 50);
	sphere4->setApperance(*apperance);
	sphere4->init();

	GLSphere3D* sphere5 = new GLSphere3D(8.0, 8.0, 0.0, 4.0, 90, 50);
	sphere5->setApperance(*apperance);
	sphere5->init();

	GLSphere3D* sphere6 = new GLSphere3D(16.0, 8.0, 0.0, 4.0, 90, 50);
	sphere6->setApperance(*apperance);
	sphere6->init();

	GLSphere3D* sphere7 = new GLSphere3D(0.0, 16.0, 0.0, 4.0, 90, 50);
	sphere7->setApperance(*apperance);
	sphere7->init();

	GLSphere3D* sphere8 = new GLSphere3D(8.0, 16.0, 0.0, 4.0, 90, 50);
	sphere8->setApperance(*apperance);
	sphere8->init();

	GLSphere3D* sphere9 = new GLSphere3D(16.0, 16.0, 0.0, 4.0, 90, 50);
	sphere9->setApperance(*apperance);
	sphere9->init();

	//layer 2
	GLSphere3D* sphere10 = new GLSphere3D(0.0, 0.0, 8.0, 4.0, 90, 50);
	sphere10->setApperance(*apperance);
	sphere10->init();

	GLSphere3D* sphere11 = new GLSphere3D(8.0, 0.0, 8.0, 4.0, 90, 50);
	sphere11->setApperance(*apperance);
	sphere11->init();

	GLSphere3D* sphere12 = new GLSphere3D(16.0, 0.0, 8.0, 4.0, 90, 50);
	sphere12->setApperance(*apperance);
	sphere12->init();

	GLSphere3D* sphere13 = new GLSphere3D(0.0, 8.0, 8.0, 4.0, 90, 50);
	sphere13->setApperance(*apperance);
	sphere13->init();

	GLSphere3D* sphere14 = new GLSphere3D(8.0, 8.0, 8.0, 4.0, 90, 50);
	sphere14->setApperance(*apperance);
	sphere14->init();

	GLSphere3D* sphere15 = new GLSphere3D(16.0, 8.0, 8.0, 4.0, 90, 50);
	sphere15->setApperance(*apperance);
	sphere15->init();

	GLSphere3D* sphere16 = new GLSphere3D(0.0, 16.0, 8.0, 4.0, 90, 50);
	sphere16->setApperance(*apperance);
	sphere16->init();

	GLSphere3D* sphere17 = new GLSphere3D(8.0, 16.0, 8.0, 4.0, 90, 50);
	sphere17->setApperance(*apperance);
	sphere17->init();

	GLSphere3D* sphere18 = new GLSphere3D(16.0, 16.0, 8.0, 4.0, 90, 50);
	sphere18->setApperance(*apperance);
	sphere18->init();

	//layer3
	GLSphere3D* sphere19 = new GLSphere3D(0.0, 0.0, 16.0, 4.0, 90, 50);
	sphere19->setApperance(*apperance);
	sphere19->init();

	GLSphere3D* sphere20 = new GLSphere3D(8.0, 0.0, 16.0, 4.0, 90, 50);
	sphere20->setApperance(*apperance);
	sphere20->init();

	GLSphere3D* sphere21 = new GLSphere3D(16.0, 0.0, 16.0, 4.0, 90, 50);
	sphere21->setApperance(*apperance);
	sphere21->init();

	GLSphere3D* sphere22 = new GLSphere3D(0.0, 8.0, 16.0, 4.0, 90, 50);
	sphere22->setApperance(*apperance);
	sphere22->init();

	GLSphere3D* sphere23 = new GLSphere3D(8.0, 8.0, 16.0, 4.0, 90, 50);
	sphere23->setApperance(*apperance);
	sphere23->init();

	GLSphere3D* sphere24 = new GLSphere3D(16.0, 8.0, 16.0, 4.0, 90, 50);
	sphere24->setApperance(*apperance);
	sphere24->init();

	GLSphere3D* sphere25 = new GLSphere3D(0.0, 16.0, 16.0, 4.0, 90, 50);
	sphere25->setApperance(*apperance);
	sphere25->init();

	GLSphere3D* sphere26 = new GLSphere3D(8.0, 16.0, 16.0, 4.0, 90, 50);
	sphere26->setApperance(*apperance);
	sphere26->init();

	GLSphere3D* sphere27 = new GLSphere3D(16.0, 16.0, 16.00, 4.0, 90, 50);
	sphere27->setApperance(*apperance);
	sphere27->init();

	material._diffuse_material = glm::vec3(1.0, 0.5, 0.0);
    material._ambient_material = glm::vec3(1.0, 0.5, 0.0);  

    apperance->updateMaterial();
    light_source1._diffuse_intensity = 1.0;
    apperance->updateLightSources();
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //// Main render loop
    
    // Set up our green background color
    static const GLfloat clear_color[] = { 0.0f, 0.0f, 0.0f, 1.0f };
    static const GLfloat clear_depth[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    
    // This sets the camera to a new location
    // the first parameter is the eye position, the second the center location, and the third the up vector. 
    SetViewAsLookAt(glm::vec3(12.0f, 12.0f, 35.5f), glm::vec3(1.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    
    
    // Enable depth test
    // ignore this line, it allows us to keep the distance value after we proejct each object to a 2d canvas.
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
   // sphere->enableNormalVectorRenderer();
    
    // This is our render loop. As long as our window remains open (ESC is not pressed), we'll continue to render things.
    while(!glfwWindowShouldClose(window))
    {
        
        // Clear the entire buffer with our green color (sets the background to be green).
        glClearBufferfv(GL_COLOR , 0, clear_color);
        glClearBufferfv(GL_DEPTH , 0, clear_depth);
        
    
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //// This renders the objects
        
        // Set the trackball locatiom
        SetTrackballLocation(trackball.getRotationMatrix());
        
        // draw the objects
        cs->draw();
        
		sphere1->draw();
		sphere2->draw();
		sphere3->draw();
		sphere4->draw();
		sphere5->draw();
		sphere6->draw();
		sphere7->draw();
		sphere8->draw(); 
		sphere9->draw();
		sphere10->draw();
		sphere11->draw();
		sphere12->draw();	
		sphere13->draw();
		sphere14->draw();
		sphere15->draw();
		sphere16->draw();
		sphere17->draw();
		sphere18->draw();		
		sphere19->draw();
		sphere20->draw();
		sphere21->draw(); 
		sphere22->draw();
		sphere23->draw();
		sphere24->draw(); 
		sphere25->draw();
		sphere26->draw();
		sphere27->draw();
		//// This renders the objects
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        
        // Swap the buffers so that what we drew will appear on the screen.
        glfwSwapBuffers(window);
        glfwPollEvents();
        
    }
    
    
    delete cs;


}

